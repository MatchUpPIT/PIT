
<!DOCTYPE html>
<html>
<head>
    <meta charset='ISO 8859-1'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='CSS/main.css'>
    
</head>
<body>
    <div class="navbar">
        <div class="nav-ul">
            <ul>
            <li style="padding-right: 15px;"><a href=""><img src="logo.png" alt="" width="70px"></a></li>
                  <li><a class="point" href="#">Home</a></li>
                  <li><a class="point" href="contato.php">Contact</a></li>
                  <li><button class="btn-log">Login</button></li>
            </ul>
        </div>
        <div class="sun" style="padding-right: 20px;"><a id="btn-sun" href=""><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-brightness-high-fill" viewBox="0 0 16 16">
            <path d="M12 8a4 4 0 1 1-8 0 4 4 0 0 1 8 0zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/>
          </svg></a></div>
    </div>
    <footer class="add1">
        <div class="wrap">
            <span class="icon-close"> <ion-icon name="close"></ion-icon></span>
            <div class="form login">
                <h2>Login</h2>
               
                <form action="verificar_login.php" method="POST">
                    <div class="input">
                        <span class="icon"><ion-icon name="mail-outline"></ion-icon></span>
                        <input class="inputs" type="email" name="email" required>
                        <label>Email:</label>
                    </div>
                    <div class="input">
                        <span class="icon"><ion-icon name="lock-closed-outline"></ion-icon></span>
                        <input type="password" name="senha" required>
                        <label>Password:</label>
                    </div>
                    <div class="remember">
                        <label><input class="check" type="checkbox"> Remember me</label>
                        <a href="#">Forgot Password?</a>
                    </div>
                    <button type="submit" class="btn">Login</button>
                    <div class="login-register">
                        <p>Não possui uma conta?<a href="#" class="register-link">Registrar</a></p>
                        <p>Quer ser um motorista?<a href="registro" class="login-link">Registro Motorista</a></p>
                    </div>
                    <?php if (isset($_GET["erro"])): ?>
                    <div class="message">
                        <?php echo htmlspecialchars($_GET["erro"]); ?>
                    </div>
                <?php endif; ?>
                </form>
             </div>

            <div class="form register">
                <h2>Resgistration</h2>
                <form action="salvar_motorista.php" method="POST">
                    <div class="input">
                        <input type="email" name="email" required>
                        <label>Email:</label>
                    </div>
                    <div class="input">
                        <input type="text" id="cpf" name="cpf" maxlength="14" required>
                        <label>CPF:</label>
                    </div>
                    <div class="input">
                        <input type="text" id="telefone" name="telefone" maxlength="15" required>
                        <label>Numero  de Telefone:</label>
                    </div>
                    <div class="input">
                        <input type="text" name="nome" required>
                        <label>Name:</label>
                    </div>
                    <div class="input">
                        <input type="password" name="senha" required>
                        <label>Password:</label>
                    </div>
                    <div class="remember">
                        <label><input class="check" type="checkbox"> Agree to the terms & conditions</label>
                    </div>
                    <button type="submit" class="btn">Register</button>
                    <div class="login-link">
                        <p>Ja tem uma conta?<a href="#" class="login-link btnLogin">Login</a></p>
                        <p>Quer ser um motorista?<a href="registro.php" class="login-link">Registro Motorista</a></p>
                    </div>
                    <div class="message">
                    <?php echo isset($mensagem) ? $mensagem : ""; ?>
                     </div>
                </form>
            </div>
        </div>
    </footer>
    <div class="tudo">
    <header>
            <div class="titulo">
                <div><h1>EduCar</h1></div>
                <div class="linha">
                    <i></i><span>&</span><i></i>
                </div>
                <div class="text">
                    <p style="padding-bottom: 20px;">Lorem Ipsum é simplesmente uma simulação de texto da indústria tipográfica e de impressos, e vem sendo utilizado desde o século XVI, quando um impressor desconhecido pegou uma bandeja de tipos e os embaralhou para fazer um livro de modelos de tipos. Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado. Se popularizou na década de 60, quando a Letraset lançou decalques contendo passagens de Lorem Ipsum, e mais recentemente quando passou a ser integrado a softwares de editoração eletrônica como Aldus PageMaker.</p>
                    <div><button>XXXX</button></div>
                </div>

            </div>
            <div class="img"><img class="img1" src="CSS/IMG/imgbin_school-bus-cartoon-png-removebg-preview.png" alt=""></div>
    </header>
    <div class="for-up">
        <div>
            <p>Lorem Ipsum é simplesmente uma simulação de texto da indústria tipográfica e de impressos, e vem sendo utilizado desde o século XVI, quando um impressor desconhecido pegou uma bandeja de tipos e os embaralhou para fazer um livro de modelos de tipos. Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado.</p>
        </div>
        <div class="linha"><i></i></div>
        <div>
            <p>Lorem Ipsum é simplesmente uma simulação de texto da indústria tipográfica e de impressos, e vem sendo utilizado desde o século XVI, quando um impressor desconhecido pegou uma bandeja de tipos e os embaralhou para fazer um livro de modelos de tipos. Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado.</p>
        </div>
        <div class="linha"><i></i></div>
        <div>
            <p>Lorem Ipsum é simplesmente uma simulação de texto da indústria tipográfica e de impressos, e vem sendo utilizado desde o século XVI, quando um impressor desconhecido pegou uma bandeja de tipos e os embaralhou para fazer um livro de modelos de tipos. Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado.</p>
        </div>
    </div>
</div>
<div class="container1">
    <div class="card">
        <div class="icon1"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
            <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4Zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10Z"/>
          </svg></div>
        <div class="content1">
            <h1>Lorem Ipsum</h1>
            <p>Lorem Ipsum é simplesmente uma simulação de texto da indústria tipográfica e de impressos, e vem sendo utilizado desde o século XVI, quando um impressor desconhecido pegou uma bandeja de tipos e os embaralhou para fazer um livro de modelos de tipos.</p>
        </div>
    </div>
    <div class="card">
        <div class="icon1">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-planet" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"> <path stroke="none" d="M0 0h24v24H0z" fill="none"/> <path d="M18.816 13.58c2.292 2.138 3.546 4 3.092 4.9c-.745 1.46 -5.783 -.259 -11.255 -3.838c-5.47 -3.579 -9.304 -7.664 -8.56 -9.123c.464 -.91 2.926 -.444 5.803 .805" /> <circle cx="12" cy="12" r="7" /> </svg>
        </div>
        <div class="content1">
            <h1>Lorem Ipsum</h1>
            <p>Lorem Ipsum é simplesmente uma simulação de texto da indústria tipográfica e de impressos, e vem sendo utilizado desde o século XVI, quando um impressor desconhecido pegou uma bandeja de tipos e os embaralhou para fazer um livro de modelos de tipos.</p>
        </div>
    </div>
    <div class="card">
        <div class="icon1">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bus-front-fill" viewBox="0 0 16 16">
                <path d="M16 7a1 1 0 0 1-1 1v3.5c0 .818-.393 1.544-1 2v2a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5V14H5v1.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-2a2.496 2.496 0 0 1-1-2V8a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1V2.64C1 1.452 1.845.408 3.064.268A43.608 43.608 0 0 1 8 0c2.1 0 3.792.136 4.936.268C14.155.408 15 1.452 15 2.64V4a1 1 0 0 1 1 1v2ZM3.552 3.22A43.306 43.306 0 0 1 8 3c1.837 0 3.353.107 4.448.22a.5.5 0 0 0 .104-.994A44.304 44.304 0 0 0 8 2c-1.876 0-3.426.109-4.552.226a.5.5 0 1 0 .104.994ZM8 4c-1.876 0-3.426.109-4.552.226A.5.5 0 0 0 3 4.723v3.554a.5.5 0 0 0 .448.497C4.574 8.891 6.124 9 8 9c1.876 0 3.426-.109 4.552-.226A.5.5 0 0 0 13 8.277V4.723a.5.5 0 0 0-.448-.497A44.304 44.304 0 0 0 8 4Zm-3 7a1 1 0 1 0-2 0 1 1 0 0 0 2 0Zm8 0a1 1 0 1 0-2 0 1 1 0 0 0 2 0Zm-7 0a1 1 0 0 0 1 1h2a1 1 0 1 0 0-2H7a1 1 0 0 0-1 1Z"/>
              </svg>
        </div>
        <div class="content1">
            <h1>Lorem Ipsum</h1>
            <p>Lorem Ipsum é simplesmente uma simulação de texto da indústria tipográfica e de impressos, e vem sendo utilizado desde o século XVI, quando um impressor desconhecido pegou uma bandeja de tipos e os embaralhou para fazer um livro de modelos de tipos.</p>
        </div>
     </div>
</div>



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.6/jquery.inputmask.min.js"></script>
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

<script src='JS/index.js'></script>
</body>
</html>