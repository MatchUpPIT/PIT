<!DOCTYPE html>
<html>
<head>
    <title>Usuário Logado</title>
</head>
<body>
    <h1>Login feito com sucesso!</h1>
    <p>Bem-vindo, usuário logado.</p>
    <!-- Conteúdo adicional para a página de usuário logado -->
</body>
</html>
