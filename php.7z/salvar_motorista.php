<?php

require_once("usuario.php");
require_once("verificar_login.php");



if ($_SERVER["REQUEST_METHOD"] == "POST") {

    echo "LOGIN FEITO COM SUCESSO";

    $email = $_POST["email"];
    $cpf = $_POST["cpf"];
    $telefone = $_POST["telefone"];
    $nome = $_POST["nome"];
    $senha = $_POST["senha"];

    $usuario = new Usuario($email, $cpf, $telefone, $nome, $senha);
    $mensagem = $usuario->salvar();

    // Verificar o login do novo usuário
    //$login = new Login($email, $senha);
    //$loginMensagem = $login->fazerLogin();
}


?>
