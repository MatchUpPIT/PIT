<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='CSS/registro.css'>
</head>
<body>
    <div class="navbar">
        <div class="nav-ul">
            <ul>
                <li style="padding-right: 15px;"><a href=""><img src="logo.png" alt="" width="70px"></a></li>
                  <li><a class="point" href="index.php">Home</a></li>
                  <li><a class="point" href="contato.php">Contact</a></li>
                  <li><button class="btn-log">Login</button></li>
            </ul>
        </div>
        <div class="sun" style="padding-right: 20px;"><a id="btn-sun" href=""><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi                  
            bi-brightness-high-fill"     viewBox="0 0 16 16">
            <path d="M12 8a4 4 0 1 1-8 0 4 4 0 0 1 8 0zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/>
          </svg></a></div>
        </div>
    
        <footer class="add1">
            <div class="wrap">
                <span class="icon-close"> <ion-icon name="close"></ion-icon></span>
                <div class="form login">
                    <h2>Login</h2>
               
                    <form action="verificar_login.php" method="POST">
                        <div class="input">
                            <span class="icon"><ion-icon name="mail-outline"></ion-icon></span>
                            <input class="inputs" type="email" name="email" required>
                            <label>Email:</label>
                        </div>
                        <div class="input">
                            <span class="icon"><ion-icon name="lock-closed-outline"></ion-icon></span>
                            <input type="password" name="senha" required>
                            <label>Password:</label>
                        </div>
                        <div class="remember">
                            <label><input class="check" type="checkbox"> Remember me</label>
                            <a href="#">Forgot Password?</a>
                        </div>
                        <button type="submit" class="btn">Login</button>
                        <div class="login-register">
                            <p>Não possui uma conta?<a href="#" class="register-link">Registrar</a></p>
                            <p>Quer ser um motorista?<a href="#" class="login-link">Registro Motorista</a></p>
                        </div>
                        <?php if (isset($_GET["erro"])): ?>
                        <div class="message">
                        <?php echo htmlspecialchars($_GET["erro"]); ?>
                        </div>
                        <?php endif; ?>
                    </form>
                </div>

                <div class="form register">
                    <h2>Resgistration</h2>
                    
                    <form action="salvar_motorista.php" method="POST">
                        <div class="input">
                            <input type="email" name="email" required>
                            <label>Email:</label>
                        </div>
                        <div class="input">
                            <input type="text" id="cpf" name="cpf" maxlength="14" required>
                            <label>CPF:</label>
                        </div>
                        <div class="input">
                            <input type="text" id="telefone" name="telefone" maxlength="15" required>
                            <label>Numero  de Telefone:</label>
                        </div>
                        <div class="input">
                            <input type="text" name="nome" required>
                            <label>Name:</label>
                        </div>
                        <div class="input">
                            <input type="password" name="senha" required>
                            <label>Password:</label>
                        </div>
                        <div class="remember">
                            <label><input class="check" type="checkbox"> Agree to the terms & conditions</label>
                        </div>
                        <button type="submit" class="btn">Register</button>
                        <div class="login-link">
                            <p>Ja tem uma conta?<a href="#" class="login-link btnLogin">Login</a></p>
                            <p>Quer ser um motorista?<a href="#" class="login-link">Registro Motorista</a></p>
                        </div>
                        <div class="message">
                            <?php echo isset($mensagem) ? $mensagem : ""; ?>
                        </div>
                    </form>
                </div>
            </div>
        </footer>
    </div>
    
        <div class="tudo">
               <div class="space">
                   <div class="dentro">
                       <div class="titulo">
                        <h1>
                            Faça seu registro
                        </h1>   
                       </div>
                        <div class="reg">
                            <div>
                                <p>Nome:</p>
                                <input type="text">
                            </div>
                            <div class="spacing"></div>
                            <div>
                                <p>Sobrenome:</p>
                                <input type="text">
                            </div>
                        </div>
                        <div class="reg inteiro">
                            <div>
                                <p>Email:</p>
                                <input type="text" placeholder="Ex: exemplo@gmail.com">
                            </div>
                        </div>
                        <div class="reg">
                            <div>
                                <p>Senha:</p>
                                <input type="text" placeholder="Ex: P000000@">
                            </div>
                            <div class="spacing"></div>
                            <div>
                                <p>Confime sua senha:</p>
                                <input type="text" placeholder="Ex: P000000@">
                            </div>
                        </div>
                        <div class="reg">
                            <div>
                                <p>CPF:</p>
                                <input type="text" placeholder="Ex: 000.000.000.00">
                            </div>
                            <div class="spacing"></div>
                            <div>
                                <p>CEP:</p>
                                <input type="text" placeholder="Ex: 000000-00">
                            </div>
                        </div>
                        <div class="arq reg">
                            <label for="">CNH do Motorista:</label>
                            <input type="file">
                        </div>
                        <div class="check">
                            <input type="checkbox">
                            <a href="registro copy.html">Eu li e aceito os contratos de serviço</a>
                        </div>
                        <div class="button">
                            <button>Registrar</button>
                        </div>
                   </div>
               </div>
        </div>
    </div>
        <div class="rodape"></div>
    
    
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.6/jquery.inputmask.min.js"></script>
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

<script src='JS/index.js'></script>
</body>
</html>